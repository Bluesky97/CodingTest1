﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly string apiKey = "5ff9ea7e3c5e4b8183c21c4d47fe68c8";
        private readonly ILogger<HomeController> _logger;

        public HomeController(IHttpClientFactory httpClientFactory, ILogger<HomeController> logger)
        {
            _httpClientFactory = httpClientFactory;
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> GetCities(string country)
        {
            if (string.IsNullOrEmpty(country))
            {
                return BadRequest("Country parameter is required.");
            }

            try
            {
                using (var client = _httpClientFactory.CreateClient())
                {
                    // Make a GET request to an endpoint that provides cities based on the country
                    var apiUrl = $"https://api.example.com/getCities?country={country}";
                    var response = await client.GetAsync(apiUrl);

                    if (response.IsSuccessStatusCode)
                    {
                        var json = await response.Content.ReadAsStringAsync();
                        _logger.LogInformation("Cities JSON Response: {Json}", json);

                        // Return the JSON data as-is
                        return Content(json, "application/json");
                    }
                    else
                    {
                        _logger.LogError("Failed to fetch cities. Status code: {StatusCode}", response.StatusCode);
                        return BadRequest("Unable to fetch cities.");
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching cities.");
                return StatusCode(500, $"An error occurred: {ex.Message}");
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetWeather(string city)
        {
            if (string.IsNullOrEmpty(city))
            {
                return BadRequest("City parameter is required.");
            }

            try
            {
                using (var client = _httpClientFactory.CreateClient())
                {
                    // Make a GET request to the Weatherbit API to fetch weather data
                    var apiUrl = $"https://api.weatherbit.io/v2.0/current?key={apiKey}&city={city}";
                    var response = await client.GetAsync(apiUrl);

                    if (response.IsSuccessStatusCode)
                    {
                        var json = await response.Content.ReadAsStringAsync();
                        _logger.LogInformation("JSON Response: {Json}", json);

                        // Convert the JSON data to a dynamic object for flexibility
                        dynamic weatherData = Newtonsoft.Json.JsonConvert.DeserializeObject(json);

                        // Perform the conversion from Celsius to Fahrenheit
                        double celsiusTemperature = weatherData.data[0].temp;
                        double fahrenheitTemperature = (celsiusTemperature * 9 / 5) + 32;

                        // Add both Celsius and Fahrenheit temperatures to the response
                        weatherData.data[0].temp_celsius = celsiusTemperature;
                        weatherData.data[0].temp_fahrenheit = fahrenheitTemperature;

                        // Return the modified JSON data as-is
                        return Content(Newtonsoft.Json.JsonConvert.SerializeObject(weatherData), "application/json");
                    }
                    else
                    {
                        _logger.LogError("Failed to fetch weather data. Status code: {StatusCode}", response.StatusCode);
                        return BadRequest("Unable to fetch weather data.");
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching weather data.");
                return StatusCode(500, $"An error occurred: {ex.Message}");
            }
        }
    }
}
