﻿namespace WebApplication1.Models
{
    public class City
    {
        public string CityName { get; set; }
    }
}
