﻿namespace WebApplication1.Models
{
    public class Country
    {
        public string CountryId { get; set; }
        public string CountryName { get; set; }
    }
}
