﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using RichardSzalay.MockHttp;
using System.Net.Http;
using System.Threading.Tasks;
using WebApplication1.Controllers;
using Xunit;

namespace WebApplication1
{
    public class WeatherControllerTests
    {
        private readonly HomeController _homeController;
        private readonly Mock<IHttpClientFactory> _httpClientFactoryMock = new Mock<IHttpClientFactory>();
        private readonly Mock<ILogger<HomeController>> _loggerMock = new Mock<ILogger<HomeController>>();

        public WeatherControllerTests()
        {
            _homeController = new HomeController(_httpClientFactoryMock.Object, _loggerMock.Object);
        }

        [Fact]
        public async Task GetWeather_ValidCity_ReturnsOkResult()
        {
            // Arrange
            string city = "New York";
            string responseContent = @"
        {
            ""data"": [
                {
                    ""city_name"": ""New York"",
                    ""app_temp"": 15.5,
                    ""clouds"": 20,
                    ""description"": ""Partly cloudy"",
                    ""temp"": 15.5,
                    ""wind_spd"": 3.2
                }
            ]
        }";

            var mockHttp = new MockHttpMessageHandler();
            mockHttp.When("https://api.weatherbit.io/v2.0/current?key=5ff9ea7e3c5e4b8183c21c4d47fe68c8&city=New%20York")
                .Respond("application/json", responseContent);

            var httpClient = new HttpClient(mockHttp);
            var httpClientFactoryMock = new Mock<IHttpClientFactory>();
            httpClientFactoryMock.Setup(factory => factory.CreateClient(It.IsAny<string>())).Returns(httpClient);

            var logger = new Mock<ILogger<HomeController>>().Object;
            var controller = new HomeController(httpClientFactoryMock.Object, logger);

            // Act
            var result = await controller.GetWeather(city);

            // Assert
            Assert.IsType<ContentResult>(result);
            var contentResult = (ContentResult)result;
            Assert.Equal("application/json", contentResult.ContentType);
        }

        [Fact]
        public async Task GetWeather_InvalidCity_ReturnsBadRequest()
        {
            // Arrange
            string city = null;

            // Act
            IActionResult result = await _homeController.GetWeather(city);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
            var badRequestResult = (BadRequestObjectResult)result;
            Assert.Equal("City parameter is required.", badRequestResult.Value);
        }

    }
}
